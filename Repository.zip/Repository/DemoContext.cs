﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace Repository
{
    public class DemoContext:DbContext
    {
        public DemoContext():base("StringDBContext") {}

        public DbSet<DemoTable> DemoTables { get; set; }
    }
}
