namespace Repository.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DemoMigration1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.DemoTables", "Number", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.DemoTables", "Number");
        }
    }
}
